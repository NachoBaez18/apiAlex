<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Impresion pagare</title>
        <link rel="stylesheet" href="C:\Users\baezn\Desktop\Bakend-2\api\resources\css\estilos.css">
    </head>
    <body>
        <h1>Pagare a la orden</h1>
        
       <div>
       
     
       <table>
           <tr>
               <td>
               <label class="tipoLetra">N°<input class="confondo"  type="text"></label>
               </td>
               <td>
               <label class="guarani">Gs.<input class="confondo" type="text"></label>
               </td>
           </tr>
           <tr>
           <td>&nbsp;</td>
           </tr>
           <tr>
           <td>&nbsp;</td>
           </tr>
           <tr>
               <td>
                   <label class="fecha"><input class="fechaFondo"type="text"></label>
               </td>
               <td>
                   <label>,</label>
                </td>
           </tr>
       </table>
    </body>
</html><?php /**PATH C:\Users\baezn\Desktop\Bakend-2\api\resources\views/pdf.blade.php ENDPATH**/ ?>